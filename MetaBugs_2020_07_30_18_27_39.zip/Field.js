class Field {
  constructor(_w, _h, _rez) {
    this.rez = _rez;
    this.cols = 1 + _w / _rez;
    this.rows = 1 + _h / _rez;
    this.field = [];
    for (let x = 0; x < this.cols; x++) {
      this.field[x] = [];
      for (let y = 0; y < this.rows; y++) {
        this.field[x][y] = 0;
      }
    }

  }

  update_values(_array) {
    for (let x = 0; x < this.cols; x++) {
      for (let y = 0; y < this.rows; y++) {
        for (let i = 0; i < _array.length; i++) {
          let object = _array[i];
          let px = x * this.rez;
          let py = y * this.rez;
          let value = sq(object.r) / (sq(px - object.x) + sq(py - object.y));
          if (value < 1) {
            this.field[x][y] += value;
          } else {
            this.field[x][y] += 1;
          }
        }
      }
    }
  }

  clear() {
    for (let x = 0; x < this.cols; x++) {
      for (let y = 0; y < this.rows; y++) {
        this.field[x][y] = 0;
      }
    }
  }

  draw(_type, _debug, _fill, _line, _weight) {
    if (_type == "marching" || _type == "smooth") {
      stroke(_line);
      strokeWeight(_weight);
      textSize(10);

      for (let x = 0; x < this.cols - 1; x++) {
        for (let y = 0; y < this.rows - 1; y++) {
          let X = x * this.rez;
          let Y = y * this.rez;

          let av = this.field[x][y];
          let bv = this.field[x + 1][y];
          let cv = this.field[x + 1][y + 1];
          let dv = this.field[x][y + 1];

          if (_debug) {
            stroke(255, 0, 0, 100);
            strokeWeight(2);
            point(X, Y);
            noStroke();
            fill(0, 255, 0);
            text(floor(av * 10) / 10, X + (this.rez / 10), Y + (this.rez / 2));
            stroke(255, 255, 0);
            strokeWeight(1);
          }

          let state = get_state(floor(av), floor(bv), floor(cv), floor(dv));

          if (_type == "marching") {
            var a = createVector(X + (this.rez / 2), Y);
            var b = createVector(X + this.rez, Y + (this.rez / 2));
            var c = createVector(X + (this.rez / 2), Y + this.rez);
            var d = createVector(X, Y + (this.rez / 2));
          } else {
            let Ax = X;
            let Ay = Y;
            let Bx = X + this.rez;
            let By = Y;
            let Cx = X + this.rez;
            let Cy = Y + this.rez;
            let Dx = X;
            let Dy = Y + this.rez;

            let lax = Ax + map((1 - av) / (bv - av), 0, 1, 0, this.rez, true);
            let lby = By + map((1 - bv) / (cv - bv), 0, 1, 0, this.rez, true);
            let lcx = Dx + map((1 - dv) / (cv - dv), 0, 1, 0, this.rez, true);
            let ldy = Ay + map((1 - av) / (dv - av), 0, 1, 0, this.rez, true);

            var a = createVector(lax, Ay);
            var b = createVector(Bx, lby);
            var c = createVector(lcx, Cy);
            var d = createVector(Dx, ldy);
          }

          switch (state) {
            case 1:
              drawLine(c, d);
              break;
            case 2:
              drawLine(b, c);
              break;
            case 3:
              drawLine(b, d);
              break;
            case 4:
              drawLine(a, b);
              break;
            case 5:
              drawLine(a, d);
              drawLine(b, c);
              break;
            case 6:
              drawLine(a, c);
              break;
            case 7:
              drawLine(a, d);
              break;
            case 8:
              drawLine(a, d);
              break;
            case 9:
              drawLine(a, c);
              break;
            case 10:
              drawLine(a, b);
              drawLine(c, d);
              break;
            case 11:
              drawLine(a, b);
              break;
            case 12:
              drawLine(b, d);
              break;
            case 13:
              drawLine(b, c);
              break;
            case 14:
              drawLine(c, d);
              break;
          }
        }
      }
    } else if (_type == "pixels") {
      fill(_fill);
      noStroke();
      for (let x = 0; x < this.cols - 1; x++) {
        for (let y = 0; y < this.rows - 1; y++) {
          let X = x * this.rez;
          let Y = y * this.rez;

          if (this.field[x][y] >= 1) {
            square(X - this.rez * 0.5, Y - this.rez * 0.5, this.rez);
          }
        }
      }
    }
  }

}

function get_state(a, b, c, d) {
  return a * 8 + b * 4 + c * 2 + d * 1;
}

function drawLine(a, b) {
  line(a.x, a.y, b.x, b.y);
}