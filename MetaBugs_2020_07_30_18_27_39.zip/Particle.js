class Particle {
  constructor(_x, _y, _r, _vx, _vy, _follow, _heading, _facing, _focuslength) {
    this.x = _x;
    this.y = _y;
    this.vx = _vx;
    this.vy = _vy;
    this.r = _r;
    if (_follow != null) {
      this.following = true;
      this.follow = _follow;
      if (_follow == "mouse") {
        this.followx = mouseX;
        this.followy = mouseY;
      } else {
        this.followx = this.follow.x;
        this.followy = this.follow.y;
      }
    } else {
      this.following = false;
      this.follow = this;
    }
    
    this.heading = _heading;
    this.facing = _facing;
    this.flength = _focuslength
  }

  distance(_px, _py) {
    return dist(_px, _py, this.x, this.y);
  }

  overlapping(_p) {
    return this.distance(_p.x, _p.y) <= this.r;
  }

  move(_bounding, _w, _h, _pad, _t) {
    if (this.following) {
      let diffx = this.follow.x - this.x;
      let diffy = this.follow.y - this.y;
      this.vx = diffx / 30;
      this.vy = diffy / 30;
    } else {
      
      if (_t < 2) {
        var thisx = this.x;
        var thisy = this.y;
      var diffx = this.heading.x - this.x;
      var diffy = this.heading.y - this.y;
      }
      let val = sq(_t) * (3 - 2 * _t);
      this.vx = (val * diffx) / 80;
      this.vy = (val * diffy) / 80;
    }
    
    this.x += this.vx;
    this.y += this.vy;

    if (_bounding != null) {
      if (_bounding == "elastic") {
        if (this.x < this.r + _pad || this.x > _w - this.r - _pad) {
          this.facing += radians(175);
          this.heading.x = this.x + this.flength * cos(this.facing);
          this.heading.y = this.y + this.flength * sin(this.facing);
        }
        if (this.y < this.r + _pad || this.y > _h - this.r - _pad) {
          this.facing += radians(175);
          this.heading.x = this.x + this.flength * cos(this.facing);
          this.heading.y = this.y + this.flength * sin(this.facing);
        }
      } else if (_bounding == "through") {
        if (this.x < -this.r + _pad) {
          this.x = _w + this.r - _pad;
        } else if (this.x > _w + this.r - _pad) {
          this.x = -this.r + _pad;
        }
        if (this.y < -this.r + _pad) {
          this.y = _h + this.r - _pad;
        } else if (this.y > _h + this.r - _pad) {
          this.y = -this.r + _pad;
        }
      }
    } else {
      _bounding = "elastic";
    }
  }

  draw(_fill, _line) {
    fill(_fill);
    stroke(_line);
    strokeWeight(1);
    circle(this.x, this.y, this.r * 2);
  }
}