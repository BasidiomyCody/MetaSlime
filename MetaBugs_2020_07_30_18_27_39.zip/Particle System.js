class ParticleSystem {
  constructor(_w, _h, _array) {
    this.w = _w;
    this.h = _h;
    this.n = 0;
    this.min_r = 0;
    this.max_r = 0;
    this.pad = 0;

    if (_array != null) {
      this.all = _array;
    } else {
      this.all = [];
    }
  }

  generate(_n, _minr, _maxr, _maxv, _pad) {
    this.min_r = _minr;
    this.max_r = _maxr;
    this.pad = _pad;
    for (let i = 0; i < _n; i++) {
      let r = random(_minr, _maxr);
      let startx = random(_pad + r, this.w - _pad - r);
      let starty = random(_pad + r, this.h - _pad - r);
      append(this.all, new Particle(startx, starty, r, random(-_maxv, _maxv), random(-_maxv, _maxv), false));
    }
  }

  generate_worm(_n, _minr, _maxr, _maxv, _pad) {
    this.min_r = _minr;
    this.max_r = _maxr;
    this.pad = _pad;
    for (let i = 0; i < _n; i++) {
      let r = map(i, 0, _n, _maxr, _minr, true);
      if (i < 1) {
        let startx = random(_pad + r, this.w - _pad - r);
        let starty = random(_pad + r, this.h - _pad - r);
        append(this.all, new Particle(startx, starty, r, random(-_maxv, _maxv), random(-_maxv, _maxv), null, createVector(startx, starty), radians(random(0, 360)), 0));
      } else {
        append(this.all, new Particle(this.all[0].x, this.all[0].y, r, 0, 0, this.all[i - 1]));
      }
    }
  }

  update(_nobounds, _t) {
    if (_nobounds != null) {
      if (_nobounds) {
        for (let i = 0; i < this.all.length; i++) {
          let p = this.all[i];
          p.move("through", this.w, this.h, this.pad, _t);
        }
      } else {
        for (let i = 0; i < this.all.length; i++) {
          let p = this.all[i];
          p.move("elastic", this.w, this.h, this.pad, _t);
        }
      }
    } else {
      for (let i = 0; i < this.all.length; i++) {
        let p = this.all[i];
        p.move("elastic", this.w, this.h, this.pad, _t);
      }
    }
  }

  draw(_fill, _line, _circle) {
    if (_circle) {
      for (let i = 0; i < this.all.length; i++) {
        let p = this.all[i];
        p.draw(_fill, _line);
      }
    } else {
      stroke(_fill);
      for (let i = 0; i < this.all.length; i++) {
        let p = this.all[i];
        strokeWeight(p.r * 2);
        point(p.x, p.y);
      }
    }
  }
}