const W = H = 1000;
let field, field2;
let T = 0;

function setup() {
  createCanvas(W, H);

  field = new Field(W, H, 12);

  MetaBalls = new ParticleSystem(W, H);

  MetaBalls.generate_worm(10, 30, 30, 0, 50);

}

function draw() {
  background(0);
  field.clear();

  //MetaBalls.update();
  Move_MetaBug(T, MetaBalls, 10, 90);

  field.update_values(MetaBalls.all);
  field.draw("smooth", false, [255, 255, 0, 255], [45, 255, 100, 255], 3);

  //MetaBalls.draw([255, 255, 0, 50], [255, 255, 0, 255], true);
}

function Move_MetaBug(T, A, _maxv, _range) {
  if (dist(A.all[0].x, A.all[0].y, A.all[0].heading.x, A.all[0].heading.y) < A.all[0].r / 2) {
    A.all[0].facing = radians(random(degrees(A.all[0].facing) - _range, degrees(A.all[0].facing) + _range));
    A.all[0].flength = random(A.all[0].r * 4, A.all[0].r * _maxv);
    A.all[0].heading.x = A.all[0].x + A.all[0].flength * cos(A.all[0].facing);
    A.all[0].heading.y = A.all[0].y + A.all[0].flength * sin(A.all[0].facing);
    if (A.all[0].heading.x < A.pad || A.all[0].heading.x > W - A.pad || A.all[0].heading.y < A.pad || A.all[0].heading.y > H - A.pad) {
      for (let its = 0; its < 5; its++) {
        A.all[0].facing = radians(random(degrees(A.all[0].facing) - (_range * (its+1) / 2), degrees(A.all[0].facing) + (_range * (its+1) / 2)));
        A.all[0].flength = random(A.all[0].r * 4, A.all[0].r * _maxv);
        A.all[0].heading.x = A.all[0].x + A.all[0].flength * cos(A.all[0].facing);
        A.all[0].heading.y = A.all[0].y + A.all[0].flength * sin(A.all[0].facing);
        if (A.all[0].heading.x > A.pad && A.all[0].heading.x < W - A.pad && A.all[0].heading.y > A.pad && A.all[0].heading.y < H - A.pad) {
         break; 
        }
      }
    }
    T = 0;
  } else {
    T++;
  }

  /*stroke(0, 255, 255);
  strokeWeight(10);
  point(A.all[0].heading.x, A.all[0].heading.y);
*/
  A.update(false, T);
}